<?php

namespace App\Controller;

use App\Entity\Survey;
use App\Entity\User;
use App\Entity\UserAnswer;
use App\Form\UserAnswerFormType;
use App\Form\UserFormType;
use App\Repository\SurveyRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;

class SurveyController extends AbstractController
{
    /**
     * @Route("/", name="homepage")
     */
    public function index(SurveyRepository $surveyRepository): Response
    {

        $survey = $surveyRepository->find(1);

        return $this->render('survey/index.html.twig', [
                             'survey' => $survey,
                            ]);
    }

    /**
     * @Route("/user", name="hello_user")
     */
    public function helloUser(Request $request): Response
    {
        $user = new User();
        $form = $this->createForm(UserFormType::class, $user);

        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $user = $form->getData();
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();

            return $this->redirectToRoute('start_survey');
        }

        return $this->render('survey/user.html.twig', [
            'user_form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/survey", name="start_survey")
     */
    public function startSurvey(): Response
    {
        return $this->render('survey/survey.html.twig');
    }

    /**
     * @Route("/thanks", name="thanks")
     */
    public function endSurvey(): Response
    {
        return $this->render('survey/thanks.html.twig', [
            'controller_name' => 'SurveyController',
        ]);
    }
}
